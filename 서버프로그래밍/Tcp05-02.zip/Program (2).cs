﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace console_tcpServer_fixedType
{
    internal class Program
    {
        static readonly int FIXEDTYPE_BUFSIZE = 40;
        static void Main(string[] args)
        {
            IPEndPoint localEP = new IPEndPoint(IPAddress.Any, 25000);
            StartServerWithFixedType(localEP);
        }

        private static void StartServerWithFixedType(IPEndPoint localEP)
        {
            Socket listenSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listenSock.SetSocketOption(SetSocketOptionLevel.Socket,SetSocketOptionName.ReceiveBuffer, 15);
            listenSock.Bind(localEP);
            listenSock.Listen();

            Console.WriteLine("[info] -- Sever Start");
            while(true) 
            { 
                Socket clientSock = listenSock.Accept();
                IPEndPoint clientEP = (IPEndPoint)clientSock.RemoteEndPoint;
                Console.WriteLine($"[info] -- connection with [{clientEP.Address}]:[{clientEP.Port}]");

                Console.WriteLine("[info] ==> RECVwating");
                byte[] sizeBuf = new byte[sizeof(int)];
                int retSizeVal = clientSock.Receive(sizeBuf, 0 , sizeBuf.Length, SocketFlags.None);
                Console.WriteLine($"[RECV-RAW]--> recvSizeVal [{RetSizeVal}]Bytes ==> ");
                int realDataSize = BitConverter.Tolnt32(sizeBuf);
                Console.WriteLine($"Data_size are [{realDataSize}] Bytes");
                byte[] dataBuf = new byte[realDataSize];
                int retDataVal = clientSock.Receive(dataBuf, 0 , dataBuf.Length , SocketFlags.None);
                Console.WriteLine($"[RECV-RAW] --> recvBytes[{retDataVal}]");
                Console.WriteLine($"[RECV=DATA] --> [{Encoding.UTF8.GetString(dataBuf)}]");
                
                Console.WriteLine("[info] ==> RECVwating");
                int retDataVal = clientSock.Receive(dataBuf, 0 , dataBuf.Length , SocketFlags.None);
                Console.WriteLine($"[RECV-RAW2] --> recvSizeVal [{retSizeVal}]Bytes ==> ");
                realDataSize = BitConverter.Toint(sizeBuf);
                Console.WriteLine($"[RECV=DATA2] --> [{Encoding.UTF8.GetString(realDateSize)}]Bytes ==>");
                dataBuf = new byte[realDataSize];
                int Total_retval = realDataSize;
                int sum_DataSize = 0;

                while(Total_retval>0)
                {
                    byte[] temp = new byte[5];
                    int retval = clientSock.Receive(dataBuf,0,dataBuf.Length, SocketFlog.None);
                    Console.WriteLine($"[RECV-RAW2] --> recvBytes[{retDataVal}]");
                    Console.WriteLine($"[RECV=DATA2] --> [{Encoding.UTF8.GetString(dataBuf)}]");
                    Array.Copy(temp,0,dataBuf,sum_DataSize,retDataVal);
                    sum_DataSize += retDataVal;
                }
                Console.WriteLine($"[RECV-Full] --> [{Encoding.UTF8.GetString(dataBuf)}]");

                // byte[] buffer = new byte[FIXEDTYPE_BUFSIZE];

                // Console.WriteLine("[info] -- RECV waiting");
                // int retval = clientSock.Receive(buffer, 0, buffer.Length, SocketFlags.None);
                // Console.WriteLine($"[RECV] --> recvBytes[{retval}]");
                // Console.WriteLine($"[RECV] --> [{Encoding.UTF8.GetString(buffer)}]");
                
        
                // clientSock.Close();
            }
        }
    }
}
