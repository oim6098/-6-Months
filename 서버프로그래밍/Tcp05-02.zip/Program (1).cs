using System.Net;
using System.Net.Sockets;
using System.Text;

namespace console_tcpClient_fixedType
{
    internal class Program
    {
        static readonly int FIXTYPE_BUFSIZE = 40;
        static readonly string terminalStr = "\n";
        static readonly string terminalStr2 = "[END]";
        static readonly byte[] terminalBufferStatic = 
        EncodIng.UTF8.GetBytes(terminalStr);

        static void Main(string[] args)
        {
            IPEndPoint remoteEP = new IPEndPoint(IPAddress.Loopback, 25000);
            sendDataWithFixedBuffer(remoteEP);  
        }

        private static void sendDataWithFixedBuffer(IPEndPoint remoteEP)
        {
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            sock.Connect(remoteEP);
            // Byte[] sendBuffer = new Byte[FIXTYPE_BUFSIZE];
            // for (int i = 0; i < FIXTYPE_BUFSIZE; i++)
            // {
            //     sendBuffer[i] = (byte)'#';
            // }

            String sendCommand = "GET Weather/Temp";
            String sendCommand2 = "POST seoul/Wind";
            byte[] DataBuf = EncodIng.UTF8.GetBytes(sendCommand);
            byte[] DataBuf = EncodIng.UTF8.GetBytes(sendCommand2);
            byte[] SizeBuf = new byte[sizeof(int)];
            byte[] SizeBuf2 = new byte[sizeof(int)];
            sizeBuf = BitConverter.GetBytes(DataBuf.Length)
            sizeBuf2 = BitConverter.GetBytes(DataBuf2.Length)
            // 호스트 2 네트워크 바이트 오더 바이트 순서변경

            //분리 전송 
            //SizeBuf 전송
            sock.Send(sizeBuf , 0 , sizeBuf.Length, SocketFlags.None);
            //DataBuf 전송
            sock.Send(DataBuf , 0 , DataBuf.Length. SocketFlags.None);
            //SizeBuf 전송2
            sock.Send(sizeBuf2 , 0 , sizeBuf2.Length, SocketFlags.None);
            //DataBuf 전송2
            sock.Send(DataBuf2 , 0 , DataBuf2.Length. SocketFlags.None);

            //합배송
            byte[] fullBytes = new byte[DataBuf2.Length + sizeBuf2.Length]
            Array.Copy(sizeBuf2, fullBytes, sizeBuf2.Length);
            Array.Copy(DataBuf2, 0 , fullBytes, sizeBuf2.Length ,DataBuf2.Length);
            sock.Send(fullBytes);

            byte[] spliteBuf1 = new byte[5];
            byte[] spliteBuf2 = new byte[5];
            byte[] spliteBuf3 = new byte[5];
            byte[] spliteBuf4 = new byte[5];
            Array.Copy(DataBuf2,        0,spliteBuf1,0,spliteBuf1.Length);
            Array.Copy(DataBuf2, spliteBuf1.Length*,  spliteBuf2, 0,spliteBuf1,0,spliteBuf1.Length);
            Array.Copy(DataBuf2, spliteBuf1.Length*2, spliteBuf3, 0,spliteBuf1,0,spliteBuf1.Length);
            Array.Copy(DataBuf2, spliteBuf1.Length*3, spliteBuf4, 0,spliteBuf1,0,spliteBuf1.Length);

            sockSend(spliteBuf12,0,SizeBuf.Length.SocketFlags.None);
            Thread.Sleep(1000);
            sockSend(spliteBuf2);
            Thread.Sleep(1000);
            sockSend(spliteBuf3);
            Thread.Sleep(1000);



            //// 발송할 버퍼에 끝문자 또는 끝나는 문자열 추가
            //Array.Copy(terminalStr. ToCharArray(), sendBuffer, terminalStr.Length);
            //Arrayy.Copy(terminalBufStr,0,sendBuffer,cmdBuff.Length,terminalBufstr);

            Array.Copy(cmdBuff, sendBuffer, cmdBuff.Length);
		
            sock.Send(sendBuffer, 0, sendBuffer.Length, SocketFlags.None);
            sock.Close();
        }
    }
}
